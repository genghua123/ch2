#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int a, b,i,j;

	printf("�п�J��ӼƦr:");
	scanf_s("%d %d", &a, &b);

	for (i = 1; i <= a; i++)
	{
		for (j = 1; j <= b; j++)
		{
			//printf("+");

			if (i == 1 || i == a || j == 1 || j == b)
			{
				printf("+");
			}
			else
			{
				printf(" ");
			}
		}
		printf("\n");
	}
	system("pause");
	return 0;
}
