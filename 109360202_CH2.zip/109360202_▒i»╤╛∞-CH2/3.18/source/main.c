#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	float dol,c;

	printf("Enter sales in dollars(-1 to end):$");
	scanf_s("%f", &dol);

	c = dol * 0.09 + 200;

	while (dol != -1)
	{
		printf("Salary is:$%f\n", c);
		
		printf("Enter sales in dollars(-1 to end):$");
		scanf_s("%f", &dol);
	}

	system("pause");
	return 0;
}