#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	float amount,rate,invest;
	int y;
	printf("�����B��5000,�Q����?\n");
	
	for (rate = 10; rate <= 12; rate = rate + 0.5)
	{
		printf("rate:%.2f\n\n", rate);

		invest = 5000;

		for (y = 1; y <= 15; y++)
		{
			amount = invest*(1 + rate/100);
			printf("year%d\tamount%.2f\n\n",y, amount);
			invest = amount;
		}
	}
	system("pause");
	return 0;
}